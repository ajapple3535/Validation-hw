/**
 * Program calculates
 *
 * Alonzo Apple
 * 9/5/2020
 */
import java.util.*;
import java.lang.*;
import java.io.*;
public class calculateCharges{
     public static void main(String []args)
     {
      Scanner sc = new Scanner(System.in);
      double minimumFee = 2.00;
      double Price;
      double totalPrice;
      System.out.println("Enter hours parked");
      double hours= sc.nextDouble();
      
      
      
      totalPrice= hours * 0.50 + minimumFee;
      
      if (totalPrice > 10){
          System.out.println("reached max price");
          totalPrice = 10;
        }
      System.out.println("the total is $" + totalPrice);
      
      
}
}
    